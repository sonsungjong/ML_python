# pip install scikit-learn
# pip install xgboost
# pip install lightgbm
# pip install catboost

# 랜덤포레스트 버전

import joblib
import pandas as pd
import numpy as np

# 1. 모델 로드 (1회만)
model = joblib.load('lzr_ai_model.joblib')

def predict_distance_array(distance_array_1096):
    arr = np.array(distance_array_1096)
    if arr.ndim != 1 or arr.shape[0] != 1096:
        raise ValueError("입력 데이터는 1차원, 길이 1096(4*274) 이어야 합니다.")
    arr = arr.reshape(1, -1)
    pred = model.predict(arr)[0]        
    return int(pred)

# 예시 입력 (실시간으로 들어오는 거리값 1096개)
test_sample = np.random.randint(0, 65001, size=1096)  # 예시: 0~65000 랜덤값

# 예측
pred = predict_distance_array(test_sample)
if pred == 1:
    print("HUMAN DETECTED")
else:
    print("NO HUMAN")